# Pointillism 
I have tried to create the Pointillism not exactly but I have tried with one color which you can see below.
to recreate it just download it and open index.html .

I have used Laplacian Filter to extract the Edge of image by using convolutions.
### Output
![Image of Output Lemons](https://github.com/robonetphy/hexbot/blob/master/entries/Umang/lemons.png)
![Image of Cute Dog ](https://github.com/robonetphy/hexbot/blob/master/entries/Umang/dog.png)
