# A simple color switcher

Not a lot to this except to call the bot and update the color. 

I'm using LINQPad with C#. [Source Code](https://github.com/hansknecht/hexbot/tree/master/entries/hansknecht)

When you first start

![Screen01](Screen01.png)



When you mouse over

![Screen2](Screen2.png)



After you click and Hexbot replies

![Screen3](Screen3.png)