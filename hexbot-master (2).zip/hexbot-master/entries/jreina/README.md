## I drew these as a kid!
The source can be found [here](https://github.com/jreina/hexbot)  
`npm install` then `npm start` to start the dev server.
![noopbot creation in black and white](noop-bw.png)
![noopbot creation in color](noop-color.png)
